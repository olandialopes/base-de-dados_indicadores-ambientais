CREATE TEMPORARY TABLE cnpjs (
    cnpj VARCHAR(30)
);

\copy cnpjs FROM './cnpjs_base.csv' WITH (FORMAT csv, HEADER true, DELIMITER ',');

DO $$
DECLARE
BEGIN
    BEGIN
        CREATE TABLE porte_ipea AS (SELECT cnpj_ipea, porte_ipea FROM tabela_ipea WHERE cnpj_ipea 
                                    IN (SELECT cnpj in cnpjs));        
    END;
END $$;

